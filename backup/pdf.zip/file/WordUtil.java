//package com.ajaxjs.file;
//
//
//import org.springframework.util.CollectionUtils;
//import sun.misc.BASE64Decoder;
//
//import javax.imageio.ImageIO;
//import java.awt.image.BufferedImage;
//import java.io.*;
//import java.nio.charset.StandardCharsets;
//import java.nio.file.Files;
//import java.nio.file.Paths;
//import java.time.Instant;
//import java.time.LocalDate;
//import java.util.Enumeration;
//import java.util.List;
//import java.util.Map;
//import java.util.zip.ZipEntry;
//import java.util.zip.ZipFile;
//import java.util.zip.ZipOutputStream;
//
//public class WordUtil {
//    // 分隔符
//    private static String separator = "/";
//    // 文件后缀
//    private static String fileSuffix = ".docx";
//
//    /**
//     * @param dataMap     传入的数据
//     * @param docTemplate docx模板文件名称，该文件可以直接使用解压软件打开docx文件，复制word/document.xml文件内容进行修改
//     * @param resXml      图片引用配置文件名
//     */
//    public static void createDocx(Map<String, Object> dataMap, String docTemplate, String resXml) {
//        int len;
//        byte[] buffer = new byte[1024];
//
//        try (OutputStream os = Files.newOutputStream(Paths.get("/Users/xin/Desktop/test.docx")); ZipOutputStream zipOut = new ZipOutputStream(os); /* 输出的 */
//             InputStream inputStream = WordUtil.class.getClassLoader().getResourceAsStream("templates/docxTemplate.docx") /* 原压缩包 */) {
//            File docxFile = new File("docxTemplate.docx");
////            FileUtils.copyToFile(inputStream, docxFile);
//
//            if (!docxFile.exists()) docxFile.createNewFile();
//
//            ZipFile zipFile = new ZipFile(docxFile); // 原压缩包
//            Enumeration<? extends ZipEntry> zipEntry = zipFile.entries();
////            ByteArrayInputStream imgData = img((List<Map<String, Object>>) dataMap.get("picList"), zipOut, dataMap, resXml);
//
//            //内容模板
//            ByteArrayInputStream documentInput = getFreemarkerContentInputStream(dataMap, docTemplate);
////
//            //开始覆盖文档------------------
//            while (zipEntry.hasMoreElements()) {
//                ZipEntry next = zipEntry.nextElement();
//                InputStream is = zipFile.getInputStream(next);
//
//                if (!next.toString().contains("media")) {
//                    zipOut.putNextEntry(new ZipEntry(next.getName()));
//
//                    if (next.getName().indexOf("document.xml.rels") > 0) { //如果是document.xml.rels由我们输入
////                        if (documentXmlRelsInput != null) {
////                            while ((len = documentXmlRelsInput.read(buffer)) != -1) zipOut.write(buffer, 0, len);
////
////                            documentXmlRelsInput.close();
////                        }
//                    } else if ("word/document.xml".equals(next.getName()) && documentInput != null) {//如果是word/document.xml由我们输入
//                        while ((len = documentInput.read(buffer)) != -1) zipOut.write(buffer, 0, len);
//                        documentInput.close();
//                    } else {
//                        while ((len = is.read(buffer)) != -1) zipOut.write(buffer, 0, len);
//
//                        is.close();
//                    }
//                }
//            }
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
//
//    /**
//     * 写入并处理图片
//     */
//    private static ByteArrayInputStream img(List<Map<String, Object>> picList, ZipOutputStream zipOut, Map<String, Object> dataMap, String resXml) throws IOException {
//        if (CollectionUtils.isEmpty(picList)) return null;
//
//        int len;
//        byte[] buffer = new byte[1024];
//
//        for (Map<String, Object> pic : picList) {
//            String imageName = pic.get("name").toString().split("\\.")[0];
//            ZipEntry next = new ZipEntry("word" + separator + "media" + separator + pic.get("name"));
//            zipOut.putNextEntry(new ZipEntry(next.toString()));
//            BASE64Decoder decoder = new BASE64Decoder();
//            byte[] bytes1 = decoder.decodeBuffer(pic.get("code").toString());
//
//            try (InputStream in = new ByteArrayInputStream(bytes1)) {
//                while ((len = in.read(buffer)) != -1) zipOut.write(buffer, 0, len);
//            }
//
//            // 处理图片宽高
//            try (InputStream imageInputStream = new ByteArrayInputStream(bytes1)) {
//                BufferedImage a = ImageIO.read(imageInputStream);
//
//                dataMap.put(imageName + "Width", a.getWidth());
//                dataMap.put(imageName + "Height", a.getHeight());
////                log.info("{}:{},{}:{}", imageName + "Width", width, imageName + "Height", height);
//            }
//        }
//
//        return getFreemarkerContentInputStream(dataMap, resXml); // 图片配置文件模板
//    }
//
//    /**
//     * 处理转义字符
//     */
//    public static String transform(String str) {
//        if (str.contains("<") || str.contains(">") || str.contains("&")) {
//            str = str.replaceAll("&", "&amp;");
//            str = str.replaceAll("<", "&lt;");
//            str = str.replaceAll(">", "&gt;");
//        }
//
//        return str;
//    }
//
//    /**
//     * base64转inputStream
//     */
//    private static InputStream toInputStream(String base64string) {
//        ByteArrayInputStream stream = null;
//
//        try {
//            BASE64Decoder decoder = new BASE64Decoder();
//            byte[] bytes1 = decoder.decodeBuffer(base64string);
//            stream = new ByteArrayInputStream(bytes1);
//        } catch (Exception e) {
//        }
//
//        return stream;
//    }
//
//    /**
//     * 获取模板字符串输入流
//     *
//     * @param dataMap      参数
//     * @param templateName 模板名称
//     * @return
//     */
////    public static ByteArrayInputStream getFreemarkerContentInputStream(Map dataMap, String templateName) {
////        ByteArrayInputStream in = null;
////        try {
////            //获取模板
////            Template template = configuration.getTemplate(templateName);
////            StringWriter swriter = new StringWriter();
////            //生成文件
////            template.process(dataMap, swriter);
////            in = new ByteArrayInputStream(swriter.toString().getBytes(StandardCharsets.UTF_8));//这里一定要设置utf-8编码 否则导出的word中中文会是乱码
////        } catch (Exception e) {
////        }
////
////        return in;
////    }
//
//    /**
//     * 删除所有的HTML标签
//     * e.g. <div>“3人伪造老干妈印章与腾讯签合同”事件</div> 去掉 div
//     *
//     * @param source 需要进行除HTML的文本
//     */
//    public static String deleteAllHTMLTag(String source) {
//        if (source == null) {
//            return "";
//        }
//        String s = source;
//        /* 删除普通标签  */
//        s = s.replaceAll("<(S*?)[^>]*>.*?|<.*? />", "");
//        /* 删除转义字符 */
////        s = s.replaceAll("&.{2,6}?;", "");
//        return s;
//    }
//}