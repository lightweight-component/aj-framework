package com.ajaxjs.file.pdf2img;


import com.ajaxjs.util.io.FileHelper;
import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.rendering.PDFRenderer;

import javax.imageio.ImageIO;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * PDF 转图片
 */
public class Pdf2img {
    /**
     * dpi越大转换后越清晰，相对转换速度越慢
     */
    private static final Integer DPI = 80;

    /**
     * PDF 转图片
     *
     * @param pdfFile   PDF 文件
     * @param outputDir 输出的目录
     */
    public static void pdf2Img(String pdfFile, String outputDir) {
        long old = System.currentTimeMillis();

        try (PDDocument document = Loader.loadPDF(new File(pdfFile))) {
            PDFRenderer renderer = new PDFRenderer(document);

            for (int i = 0; i < document.getNumberOfPages(); ++i) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                ImageIO.write(renderer.renderImageWithDPI(i, DPI), "gif", out);

                // 将字节数组写入到文件
                try (FileOutputStream fos = new FileOutputStream(outputDir + FileHelper.SEPARATOR + "img-" + i + ".gif")) {
                    fos.write(out.toByteArray());
                }
            }

            System.out.println("pdf2img共耗时：" + (System.currentTimeMillis() - old) / 1000.0 + "秒");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
