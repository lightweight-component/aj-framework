package com.ajaxjs.file;

import com.ajaxjs.file.pdf2img.Pdf2img;
import org.junit.Test;

public class TestPdf2Img {
    @Test
    public void test() {
        Pdf2img.pdf2Img("D:\\code\\aj-private\\aj-backend\\aj-play\\src\\test\\java\\com\\ajaxjs\\file\\test.pdf","c:\\temp\\img");
    }
}
