package com.ajaxjs.file.word2pdf;

import org.apache.poi.xwpf.converter.pdf.PdfOptions;
import org.junit.Test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class TestWord2Pdf {
    @Test
    public void testWordPdfUtils() throws Exception {
        Path path = Paths.get("c:/temp/test.pdf");
        Files.deleteIfExists(path);

        String filepath = "C:/temp/short-contract-template.docx";

        InputStream source = Files.newInputStream(Paths.get(filepath));
        OutputStream target = Files.newOutputStream(path);
        Map<String, String> params = new HashMap<>();

        PdfOptions options = PdfOptions.create();

        WordPdfUtils.wordConverterToPdf(source, target, options, params);
    }

    @Test
    public void testAsposeWordPdfUtils() throws IOException {
        Path path = Paths.get("c:/temp/test.pdf");
        Files.deleteIfExists(path);

        AsposeUtil.word2pdf("C:/temp/short-contract-template.docx", "c:/temp/test.pdf");
    }
}
